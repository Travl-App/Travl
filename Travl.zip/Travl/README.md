# Travl
App for travelers

Tech Stack:
1. Moxy
2. Retrofit
3. RxJava2
4. Dagger2
5. Java
6. Cicerone
7. Glide
8. ButterKnife
9. A bit of Kotlin.
