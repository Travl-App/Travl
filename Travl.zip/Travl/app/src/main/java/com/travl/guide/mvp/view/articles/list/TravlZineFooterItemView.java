package com.travl.guide.mvp.view.articles.list;

public interface TravlZineFooterItemView {
    void loadMoreArticles();
}
