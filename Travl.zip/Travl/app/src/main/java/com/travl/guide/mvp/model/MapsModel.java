package com.travl.guide.mvp.model;

public class MapsModel {
    public MapsModel() {}
}
