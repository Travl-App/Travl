package com.travl.guide.ui.activity;

public interface CoordinatesProvider {
    double[] getCoordinates();
}
