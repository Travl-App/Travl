package com.travl.guide.mvp.model.favorite;

//Created by Pereved on 29.03.2019.
public class FavoriteModel {
    public FavoriteModel(){}
}
