package com.travl.guide.ui.activity;

public interface SharedDataProvider {
    String getSharedData();
}
