package com.travl.guide.util;

import android.Manifest;

public class UtilVariables {
    public static final String COARSE_LOCATION_PERMISSION = Manifest.permission.ACCESS_COARSE_LOCATION;
    public static final String FINE_LOCATION_PERMISSION = Manifest.permission.ACCESS_FINE_LOCATION;
    public static final int LOCATION_PERMISSIONS_REQUEST_CODE = 0;
}
