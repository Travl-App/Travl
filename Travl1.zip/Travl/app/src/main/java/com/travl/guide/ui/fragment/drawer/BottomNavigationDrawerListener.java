package com.travl.guide.ui.fragment.drawer;

public interface BottomNavigationDrawerListener {
    void navToMapScreen();

    void navToTravlZineScreen();

    void navToFavoriteScreen();

    void navToStartPageScreen();
}
